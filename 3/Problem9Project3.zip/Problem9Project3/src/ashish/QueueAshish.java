package ashish;
import java.util.Queue;
import java.util.LinkedList;

public class QueueAshish {
	    public static void main(String[] args) {
	        Queue<Integer> queue = new LinkedList<>();
	        queue.add(23);
	        queue.add(11);
	        queue.add(22);
	        queue.add(66);
	        queue.add(32);

	        System.out.println("Queue" + queue);
	        int removedElement = queue.poll();
	        System.out.println("Removed element" + removedElement);

	        System.out.println("Queue after removing an element " + queue);
	    }
	}

