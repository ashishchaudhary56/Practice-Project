package ashish;

public class CircularLinkedList {
	
	    private Node head;

	    private class Node {
	        int data;
	        Node next;

	        Node(int data) {
	            this.data = data;
	            this.next = null;
	        }
	    }

	    public void insert(int data) {
	        Node newNode = new Node(data);
	        if (head == null) {
	            newNode.next = newNode;
	            head = newNode;
	        } else if (data <= head.data) {
	            Node lastNode = getLastNode();
	            newNode.next = head;
	            lastNode.next = newNode;
	            head = newNode;
	        } else {
	            Node currentNode = head;
	            while (currentNode.next != head && currentNode.next.data < data) {
	                currentNode = currentNode.next;
	            }
	            newNode.next = currentNode.next;
	            currentNode.next = newNode;
	        }
	    }

	    private Node getLastNode() {
	        Node currentNode = head;
	        while (currentNode.next != head) {
	            currentNode = currentNode.next;
	        }
	        return currentNode;
	    }

	    public void display() {
	        if (head == null) {
	            System.out.println("Circular linked list is empty");
	            return;
	        }

	        Node currentNode = head;
	        do {
	            System.out.print(currentNode.data + " ");
	            currentNode = currentNode.next;
	        } while (currentNode != head);
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        CircularLinkedList circularLinkedList = new CircularLinkedList();

	        circularLinkedList.insert(1);
	        circularLinkedList.insert(2);
	        circularLinkedList.insert(3);
	        circularLinkedList.insert(4);
	        circularLinkedList.insert(5);

	        System.out.print("Circular linked list ");
	        circularLinkedList.display();
	    }
	}



