package ashish;

public class LinkedList {
	
	    private Node head;

	    private class Node {
	        int data;
	        Node next;

	        Node(int data) {
	            this.data = data;
	            this.next = null;
	        }
	    }

	    public void insert(int data) {
	        Node newNode = new Node(data);
	        if (head == null) {
	            head = newNode;
	        } else {
	            Node currentNode = head;
	            while (currentNode.next != null) {
	                currentNode = currentNode.next;
	            }
	            currentNode.next = newNode;
	        }
	    }

	    public void delete(int key) {
	        if (head == null) {
	            System.out.println("Linked list is empty.");
	            return;
	        }

	        if (head.data == key) {
	            head = head.next;
	            return;
	        }

	        Node prevNode = head;
	        Node currentNode = head.next;

	        while (currentNode != null && currentNode.data != key) {
	            prevNode = currentNode;
	            currentNode = currentNode.next;
	        }

	        if (currentNode == null) {
	            System.out.println("Key not found in the linked list.");
	            return;
	        }

	        prevNode.next = currentNode.next;
	    }

	    public void display() {
	        if (head == null) {
	            System.out.println("Linked list is empty.");
	            return;
	        }

	        Node currentNode = head;
	        while (currentNode != null) {
	            System.out.print(currentNode.data + " ");
	            currentNode = currentNode.next;
	        }
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        LinkedList linkedList = new LinkedList();

	        linkedList.insert(10);
	        linkedList.insert(20);
	        linkedList.insert(30);
	        linkedList.insert(40);
	        linkedList.insert(50);

	        System.out.print(" before deletion: ");
	        linkedList.display();

	        int key = 10;
	        linkedList.delete(key);
	        System.out.println("Delete " + key);

	        System.out.print("After Deletion ");
	        linkedList.display();
	    }
	}



