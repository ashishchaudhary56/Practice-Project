package ashish;

public class MatrixMultiply {

	public static void main(String[] args) {
			int a1[][]={{5,1,5},{2,4,6},{4,1,5}};    
			int a2[][]={{9,11,1},{8,12,7},{2,3,4}};        
			int a3[][]=new int[3][3];  
			for(int i=0;i<3;i++){    
			for(int j=0;j<3;j++){    
			a3[i][j]=0;      
			for(int k=0;k<3;k++)      
			{      
			a3[i][j]+=a1[i][k]*a2[k][j];   
			}
			System.out.print(a3[i][j]+" ");  
			}
			System.out.println();   
			}   
			}}

	
	
