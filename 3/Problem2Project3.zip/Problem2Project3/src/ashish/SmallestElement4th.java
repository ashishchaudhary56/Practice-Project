package ashish;

import java.util.Arrays;

public class SmallestElement4th {
	public static int ashish(int[] arr) {
        if (arr == null || arr.length < 4) {
            throw new IllegalArgumentException("array should contain at least four elements");
        }
        Arrays.sort(arr);
        return arr[3];
    }

	public static void main(String[] args) {
		int[] arr = {4,5,67,543,123,456,44,2};
        int fourthSmallest = ashish(arr);
        System.out.println("The fourth smallest element is " + fourthSmallest);
    }

	}


