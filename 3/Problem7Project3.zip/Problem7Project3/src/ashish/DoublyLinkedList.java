package ashish;

public class DoublyLinkedList {

	    private Node head;
	    private class Node {
	        int data;
	        Node prev;
	        Node next;

	        Node(int data) {
	            this.data = data;
	            this.prev = null;
	            this.next = null;
	        }
	    }

	    public void insert(int data) {
	        Node newNode = new Node(data);
	        if (head == null) {
	            head = newNode;
	        } else {
	            Node currentNode = head;
	            while (currentNode.next != null) {
	                currentNode = currentNode.next;
	            }
	            currentNode.next = newNode;
	            newNode.prev = currentNode;
	        }
	    }

	    public void traverseForward() {
	        if (head == null) {
	            System.out.println("Doubly linked list is empty");
	            return;
	        }

	        System.out.print("Forward traversal ");
	        Node currentNode = head;
	        while (currentNode != null) {
	            System.out.print(currentNode.data + " ");
	            currentNode = currentNode.next;
	        }
	        System.out.println();
	    }

	    public void traverseBackward() {
	        if (head == null) {
	            System.out.println("Doubly linked list is empty");
	            return;
	        }

	        System.out.print("Backward traversal ");
	        Node currentNode = getLastNode();
	        while (currentNode != null) {
	            System.out.print(currentNode.data + " ");
	            currentNode = currentNode.prev;
	        }
	        System.out.println();
	    }

	    private Node getLastNode() {
	        Node currentNode = head;
	        while (currentNode.next != null) {
	            currentNode = currentNode.next;
	        }
	        return currentNode;
	    }

	    public static void main(String[] args) {
	        DoublyLinkedList doublyLinkedList = new DoublyLinkedList();

	        doublyLinkedList.insert(34);
	        doublyLinkedList.insert(12);
	        doublyLinkedList.insert(56);
	        doublyLinkedList.insert(56);
	        doublyLinkedList.insert(21);

	        doublyLinkedList.traverseForward();
	        doublyLinkedList.traverseBackward();
	    }
	}

