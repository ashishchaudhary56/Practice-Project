public class TypeCasting {
    public static void main(String[] args) {
        int a = 10;
        double b = a;
        System.out.println("Implicit casting: a = " + a + ", b = " + b);
        double c = 15.5;
        int d = (int) c;
        System.out.println("Explicit casting: c = " + c + ", d = " + d);
}}
