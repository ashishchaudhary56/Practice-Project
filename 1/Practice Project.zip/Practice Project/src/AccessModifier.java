//class Data {
//    private String name;
//    public String getName() {
//        return this.name;
//    }
//    public void setName(String name) {
//        this.name= name;
//    }
//}
class Ashish {
    public int legCount;
    public void display() {
        System.out.println("I am a Boy.");
        System.out.println("I have " + legCount + " legs.");
    }}
public class AccessModifier {
    public static void main(String[] main){
        Ashish ashish = new Ashish();
        ashish.legCount = 2;
        ashish.display();
    }}
//        Data d = new Data();
//        d.setName("Ashish");
//        System.out.println(d.getName());
//    }
//}

