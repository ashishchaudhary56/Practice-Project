public class CallingMethod {


        public static void main(String[] args) {


            Calculator mathura = new Calculator();
            int result1 = mathura.add(5, 3);
            System.out.println("5 + 3 = " + result1);
            int result2 = mathura.multiply(4, 6);
            System.out.println("4 * 6 = " + result2);

            String output = mathura.sayHello("ashish");
            System.out.println(output);
        }
    }

    class Calculator {

        public int add(int a, int b) {
            return a + b;
        }

        public int multiply(int a, int b) {
            return a * b;
        }

        public String sayHello(String name) {
            return "Hello " + name + "!";
        }
    }


