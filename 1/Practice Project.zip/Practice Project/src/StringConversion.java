public class StringConversion {
    public static void main(String[] args) {


        String str = "Ashish Chaudhary";


        StringBuffer buffer = new StringBuffer(str);

        StringBuilder builder = new StringBuilder(str);

        // Now we print output
        System.out.println("Original = " + str);
        System.out.println("StringBuffer = " + buffer);
        System.out.println("StringBuilder =" + builder);
        String abc="ashish";
        System.out.println(abc.length());
        String a1="chaudhary";
        System.out.println(a1.substring(5));
        String a2="helloWorld";
        String a3="helloWord";
        System.out.println(a2.compareTo(a3));
        System.out.println(a2.replace("h","o"));
        System.out.println(a2.equals(a3));


    }
}