import java.util.*;
public class InnerClass {
    private String abc="Hello World";
    class Inner {
        void hello(){
        System.out.println(abc);
    }
}
    public static void main(String[] args) {
        InnerClass obj =new InnerClass();
        InnerClass.Inner hi = obj.new Inner();
        hi.hello();
    }}

abstract class AnonymousInnerClass{
             public abstract void display();
        }
