public class InnerClass2 {
    private String abc = "Inner Classes";

    void display() {
        class Inner {
            void abc() {
                System.out.println(abc);
            }
        }
        Inner I = new Inner();
        I.abc();
    }

    public static void main(String[] args) {
        InnerClass2 ob = new InnerClass2();
        ob.display();
    }
}
