import java.util.Scanner;
public class Arrays {

    public static void main(String[] args)
    {
        int n;
        Scanner ashish=new Scanner(System.in);
        System.out.print("Enter size of array ");
        n=ashish.nextInt();
        int[] chaudhary = new int[10];
        System.out.println("Enter the elements of the array ");
        for(int i=0; i<n; i++)
        {
            chaudhary[i]=ashish.nextInt();
        }
        System.out.println("Array elements are: ");

        for (int i=0; i<n; i++)
        {
            System.out.println(chaudhary[i]);
        }
        int [] me={2,3,1,4};
        System.out.println("length of array" + me.length);
    }  }
