import java.util.Map;
import java.util.HashMap;
import java.util.*;
public class MapExample {
    public static void main(String[] args) {
        HashMap<String, Integer> numbers = new HashMap<>();
        numbers.put("One", 1);
        numbers.put("Two", 2);
//        System.out.println("Map " + numbers);
//        System.out.println("Keys " + numbers.keySet());
//        System.out.println("Values " + numbers.values());
//        System.out.println("Entries " + numbers.entrySet());
//        int value = numbers.remove("Two");
//        System.out.println("Removed Value:" + value);

        Hashtable<Integer, String> me = new Hashtable<Integer, String>();
        me.put(1, "i");
        me.put(2, "am");
        me.put(3, "indian");
//        System.out.println("Hashtable" + me);
//        System.out.println("Keys " + me.keySet());
//        System.out.println("Values " + me.values());
//        System.out.println("Entries " + me.entrySet());
        TreeMap<Integer,String> ashish=new TreeMap<Integer,String>();
        ashish.put(8,"mathura");
        ashish.put(9,"vrindavan");
        ashish.put(10,"govardhan");

        System.out.println("Keys " + ashish.keySet());
        System.out.println("Values " + ashish.values());
        System.out.println("Entries " + ashish.entrySet());
        System.out.println("TreeMap" + ashish);

    }}






