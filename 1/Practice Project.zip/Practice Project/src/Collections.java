import java.util.*;
public class Collections {
    public static void main(String args[]) {
        HashSet<String> set = new HashSet<String>();
        set.add("ashish");
        set.add("chaudhary");
        set.add("up");
        set.add("india");
      System.out.println(set);

        Vector<Integer> me1 = new Vector();
        me1.addElement(15);
        me1.addElement(30);
       System.out.println(me1);
        LinkedList<Integer> me2=new LinkedList<Integer>();
        me2.add(12);
        me2.add(5);
        Iterator<Integer> itr=me2.iterator();
        while(itr.hasNext()){
            System.out.println(itr.next());

        }
        ArrayList<String> me = new ArrayList<String>();


        me.add("My");
        me.add("name");
        me.add("is");
        me.add("Ashish");
        me.add("Chaudhary");
          System.out.println(me);

        Stack<String> stack = new Stack<String>();
        stack.push("My");
        stack.push("name");
        stack.push("is");
        stack.push("Ashish");
        stack.push("Chaudhary");
        stack.pop();
   System.out.println(stack);
    }


}
