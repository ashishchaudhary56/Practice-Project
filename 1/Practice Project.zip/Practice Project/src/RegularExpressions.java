import java.util.regex.Pattern;
public class RegularExpressions {
    public static void main(String args[])
    {
        System.out.println(Pattern.matches(
                "Ashi*h", "Ashish"));

        System.out.println(Pattern.matches("[ash]", "a"));
        System.out.println(Pattern.matches("[amn]", "ammmna"));
    }
}
