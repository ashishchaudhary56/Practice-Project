package ashish;
import java.util.Arrays;

public class BubbleSort {
	 public static void main(String[] args) {
		 System.out.println("Bubble Sort");
		 int[] arr = { 12, 6, 113, 001, 112, 411, 5 };
		 System.out.println("GIVEN ARRAY : " + Arrays.toString(arr));
		 bubbleSort(arr); System.out.println("SORTED ARRAY : " + Arrays.toString(arr)); }
	 private static void bubbleSort(int[] arr) {
		 for (int i = arr.length - 1; i > 0; i--) { 
			 for (int j = 0; j < i; j++) { 
				 if (arr[j + 1] < arr[j]) { 
					 int temp = arr[j]; arr[j] = arr[j + 1]; arr[j + 1] = temp; } } } } }
			 
		 