package ashish;

public class LinearSearch{    
public static int linearSearch(int[] arr, int key){    
        for(int i=0;i<arr.length;i++){    
            if( arr[i]==key) {    
                return  i;    
            }    
        }    
        return -1;    
    }    
    public static void main(String args[]){    
        int[] array= {45,32,12,56,44,111};    
        int key = 12;    
        System.out.println(key+" is found at : "+linearSearch(array, key));    
    }    
}