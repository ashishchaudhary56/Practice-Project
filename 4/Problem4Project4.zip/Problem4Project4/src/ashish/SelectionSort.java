package ashish;
import java.util.*;

public class SelectionSort {
	public static void main(String[] args) {
		System.out.println("Selection Sort");

		int[] arr = {9,62,31,122,2,34,25};

		System.out.println("GIVEN ARRAY:"+ Arrays.toString(arr));

		selectionSort(arr);

		System.out.println("SORTED ARRAY:"+ Arrays.toString(arr));
	}

		private static void selectionSort(int[] array) {

		for (int i=0; i < array.length; i++) {

		int minIndex = i;

		for (int j=i+1;j< array.length; j++) {

		if (array[j] < array[minIndex]) { 
			minIndex=j ;
		}}

	

		if (i != minIndex) {
			int temp =array[i];
array[i] = array[minIndex];
array[minIndex] = temp;
}}}}
