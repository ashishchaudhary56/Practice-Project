package ashish;
import java.util.Arrays;
public class InsertionSort {
	  public static void main(String[] args) {
		  System.out.println("Insertion Sort ");
		  int[] arr = { 12, 12, 33, 111, 4444, 345, 5 }; 
		  System.out.println("GIVEN ARRAY : " + Arrays.toString(arr));
		  insertionSort(arr); System.out.println("SORTED ARRAY : " + Arrays.toString(arr)); }
	  private static void insertionSort(int[] arr) { 
		  for (int i = 1; i < arr.length; i++) { 
			  int temp = arr[i]; int j = i - 1; while (j > -1 && temp < arr[j]) {
			 arr[j + 1] = arr[j]; arr[j] = temp; j--; 
		  
	  }
	  }
}}
