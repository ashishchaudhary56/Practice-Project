package ashish;

public class BinarySearch{  
	 public static void binarySearch(int array[], int fir, int las, int keyValue){  
	   int midd = (fir + las)/2;  
	   while( fir <= las ){  
	      if ( array[midd] < keyValue ){  
	        fir = midd + 1;     
	      }else if ( array[midd] == keyValue ){  
	        System.out.println("Element is found at index: " + midd);  
	        break;  
	      }else{  
	         las = midd - 1;  
	      }  
	      midd = (fir + las)/2;  
	   }  
	   if ( fir > las ){  
	      System.out.println("Element is not found");  
	   }  
	 }  
	 public static void main(String args[]){  
	        int arr[] = {10,20,30,40,50};  
	        int key = 30;  
	        int last=arr.length-1;  
	        binarySearch(arr,0,last,key);     
	 }  
	}  
