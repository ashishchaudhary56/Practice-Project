package ashish;

public class ExponentialSearch {
    
    public static int exponential(int[] arr, int myTarget) {
        int n = arr.length;
        
        if (arr[0] == myTarget) {
            return 0; 
        }
        
        int i = 1;
        while (i < n && arr[i] <= myTarget) {
            i *= 2; 
        }
        
        return binarySearch(arr, myTarget, i / 2, Math.min(i, n - 1));
    }
    
    public static int binarySearch(int[] arr, int target, int lef, int rig) {
        while (lef <= rig) {
            int mid = lef + (rig - lef) / 2;
            
            if (arr[mid] == target) {
                return mid; 
            } else if (arr[mid] < target) {
                lef = mid + 1; 
            } else {
                rig = mid - 1; 
            }
        }
        
        return -1; 
    }
    public static void main(String[] args) {
        int[] arr = {34,32,1,34,56,43,4567,4,};
        int target = 4567;
        int result = exponential(arr, target);
        if (result == -1) {
            System.out.println("MyTarget element not found in the array");
        } else {
            System.out.println("MyTarget element found at index " + result + ".");
        }
    }
}
