package ashish;

public class MergeSort {
    public static void mergesortmethod(int[] arr) {
        if (arr.length < 2) {
            return; 
        }
        
        int mid = arr.length / 2;
        int[] arrLeft = new int[mid];
        int[] arrRgt = new int[arr.length - mid];
        
    
        for (int a = 0; a < mid; a++) {
            arrLeft[a] = arr[a];
        }
        for (int b = mid; b < arr.length; b++) {
            arrRgt[b - mid] = arr[b];
        }
        
       
        mergesortmethod(arrLeft);
        mergesortmethod(arrRgt);
     
        merge(arr, arrLeft, arrRgt);
    }
    
    private static void merge(int[] array, int[] leftArray, int[] rightArray) {
        int i = 0; 
        int j = 0; 
        int k = 0; 
        
        
        while (i < leftArray.length && j < rightArray.length) {
            if (leftArray[i] <= rightArray[j]) {
                array[k++] = leftArray[i++];
            } else {
                array[k++] = rightArray[j++];
            }
        }
        
        while (i < leftArray.length) {
            array[k++] = leftArray[i++];
        }
        
  
        while (j < rightArray.length) {
            array[k++] = rightArray[j++];
        }
    }
    
    public static void main(String[] args) {
    	System.out.println("merge Sort");
        int[] array = { 344444444,243333,43334,765,2234,75 };
        
        System.out.println("Old Array");
        printArray(array);
        
        mergesortmethod(array);
        
        System.out.println("Array after Sorting");
        printArray(array);
    }
    
    private static void printArray(int[] array) {
        for (int i : array) {
            System.out.print(i + " ");
        }
        System.out.println();
    }
}
