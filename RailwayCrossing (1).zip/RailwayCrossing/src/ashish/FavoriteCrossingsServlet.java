package ashish;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/FavoriteCrossingsServlet")
public class FavoriteCrossingsServlet extends HttpServlet {
private static final long serialVersionUID = 1L;
// JDBC database URL, username, and password
private static final String DB_URL = "jdbc:mysql://localhost:3306/railway";
private static final String DB_USERNAME = "root";
private static final String DB_PASSWORD = "Simplilearn";
// JDBC driver and connection variables
private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
private Connection conn;
@Override
public void init() throws ServletException {
super.init();
try {
// Register JDBC driver
Class.forName(JDBC_DRIVER);
// Open a connection to the database
conn = DriverManager.getConnection(DB_URL, DB_USERNAME,
DB_PASSWORD);
} catch (ClassNotFoundException | SQLException e) {
e.printStackTrace();
throw new ServletException("Database connection error: " +
e.getMessage());
}
}
@Override
public void destroy() {
super.destroy();
try {
// Close the database connection
if (conn != null && !conn.isClosed()) {
conn.close();
}
} catch (SQLException e) {
e.printStackTrace();
}
}
protected void doGet(HttpServletRequest request, HttpServletResponse
response)
throws ServletException, IOException {
String markFavoriteParam = request.getParameter("markFavorite");
String removeFavoriteParam = request.getParameter("removeFavorite");
if (markFavoriteParam != null && !markFavoriteParam.isEmpty()) {
int crossingId = Integer.parseInt(markFavoriteParam);
markFavorite(crossingId, request);
} else if (removeFavoriteParam != null && !removeFavoriteParam.isEmpty())
{
int crossingId = Integer.parseInt(removeFavoriteParam);
removeFavorite(crossingId, request);
}
response.sendRedirect(request.getContextPath() + "/DashboardServlet");
}
private void markFavorite(int crossingId, HttpServletRequest request) {
List<Integer> favoriteCrossings = (List<Integer>)
request.getSession().getAttribute("favoriteCrossings");
if (favoriteCrossings == null) {
favoriteCrossings = new ArrayList<>();
}
favoriteCrossings.add(crossingId);
request.getSession().setAttribute("favoriteCrossings", favoriteCrossings);
}
private void removeFavorite(int crossingId, HttpServletRequest request) {
List<Integer> favoriteCrossings = (List<Integer>)
request.getSession().getAttribute("favoriteCrossings");
if (favoriteCrossings != null) {
favoriteCrossings.remove(Integer.valueOf(crossingId));
request.getSession().setAttribute("favoriteCrossings", favoriteCrossings);
}
}
}