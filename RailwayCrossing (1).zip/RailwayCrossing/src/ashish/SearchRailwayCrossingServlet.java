package ashish;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/SearchRailwayCrossingServlet")
public class SearchRailwayCrossingServlet extends HttpServlet {
private static final long serialVersionUID = 1L;
// JDBC database URL, username, and password
private static final String DB_URL =
"jdbc:mysql://localhost:3306/railway";
private static final String DB_USERNAME = "root";
private static final String DB_PASSWORD = "Simplilearn";
protected void doGet(HttpServletRequest request, HttpServletResponse
response)
throws ServletException, IOException {
response.setContentType("text/html");
PrintWriter out = response.getWriter();
String keyword = request.getParameter("keyword");
try {
// Create a connection to the database
Class.forName("com.mysql.jdbc.Driver");
Connection conn = DriverManager.getConnection(DB_URL,
DB_USERNAME, DB_PASSWORD);
// Prepare the SQL statement
String sql = "SELECT * FROM railway_crossings WHERE name LIKE ?";
PreparedStatement statement = conn.prepareStatement(sql);
statement.setString(1, "%" + keyword + "%");
// Execute the query
ResultSet resultSet = statement.executeQuery();
// Create a list to hold the search results
List<RailwayCrossing> crossings = new ArrayList<>();
// Iterate over the result set and add each crossing to the list
while (resultSet.next()) {
int id = resultSet.getInt("id");
String name = resultSet.getString("name");
String address = resultSet.getString("address");
String landmark = resultSet.getString("landmark");
String schedules = resultSet.getString("schedules");
String person = resultSet.getString("person");
String status = resultSet.getString("status");
RailwayCrossing crossing = new RailwayCrossing(id, name,
address, landmark, schedules, person, status);
crossings.add(crossing);
}
// Close the database connections
statement.close();
conn.close();
// Display the search results
out.println("<html>");
out.println("<head><title>Search Results</title>");
out.println("<style>");
out.println("table {");
out.println(" border-collapse: collapse;");
out.println(" width: 100%;");
out.println("}");
out.println("th, td {");
out.println(" padding: 8px;");
out.println(" text-align: left;");
out.println("}");
out.println("th {");
out.println(" background-color: #f2f2f2;");
out.println("}");
out.println("td:not(:last-child) {");
out.println(" padding-right: 20px;");
out.println("}");
out.println("</style>");
out.println("</style>");
out.println("</head>");
out.println("<body>");
out.println("<h1>Search Results</h1>");
out.println("<table>");
out.println("<tr><th>ID</th><th>Name</th><th>Address</th><th>Landmark</th><th>Schedules</th><th>Person</th><th>Status</th><th>Action</th</tr>");
// Iterate over the search results and display them in the table
for (RailwayCrossing crossing : crossings) {
out.println("<tr>");
out.println("<td>" + crossing.getId() + "</td>");
out.println("<td>" + crossing.getName() + "</td>");
out.println("<td>" + crossing.getAddress() + "</td>");
out.println("<td>" + crossing.getLandmark() + "</td>");
out.println("<td>" + crossing.getSchedules() + "</td>");
out.println("<td>" + crossing.getPerson() + "</td>");
out.println("<td>" + crossing.getStatus() + "</td>");
out.println("<td>");
out.println("<a href='update_railway.jsp?id=" + crossing.getId() +
"'>Update</a> | ");
out.println("<a href='DeleteRailwayCrossingServlet?id=" +
crossing.getId() + "'>Delete</a>");
out.println("</td>");
out.println("</tr>");
}
out.println("</table>");
out.println("</body>");
out.println("</html>");
} catch (ClassNotFoundException | SQLException e) {
e.printStackTrace();
out.println("Database error: " + e.getMessage());
}
}
}
	