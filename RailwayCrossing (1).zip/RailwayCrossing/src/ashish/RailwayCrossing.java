package ashish;

public class RailwayCrossing {
private int id;
private String name;
private String address;
private String landmark;
private String schedules;
private String person;
private String status;
public RailwayCrossing(int id, String name, String address, String
landmark, String schedules, String person, String status) {
this.id = id;
this.name = name;
this.address = address;
this.landmark = landmark;
this.schedules = schedules;
this.person = person;
this.status = status;
}
public int getId() {
return id;
}
public String getName() {
return name;
}
public String getAddress() {
return address;
}
public String getLandmark() {
return landmark;
}
public String getSchedules() {
return schedules;
}
public String getPerson() {
return person;
}
public String getStatus() {
return status;
}
}
