package ashish;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/GetRailwayDetailsServlet")
public class GetRailwayDetailsServlet extends HttpServlet {
private static final long serialVersionUID = 1L;
// JDBC database URL, username, and password
private static final String DB_URL =
"jdbc:mysql://localhost:3306/railway";
private static final String DB_USERNAME = "root";
private static final String DB_PASSWORD = "Simplilearn";
protected void doGet(HttpServletRequest request, HttpServletResponse
response)
throws ServletException, IOException {
response.setContentType("text/html");
PrintWriter out = response.getWriter();
try {
// Create a connection to the database
Class.forName("com.mysql.jdbc.Driver");
Connection conn = DriverManager.getConnection(DB_URL,
DB_USERNAME, DB_PASSWORD);
// Prepare the SQL statement
String sql = "SELECT * FROM railway_crossings";
PreparedStatement statement = conn.prepareStatement(sql);
// Execute the query
ResultSet resultSet = statement.executeQuery();
// Generate HTML output
out.println("<!DOCTYPE html>");
out.println("<html>");
out.println("<head>");
out.println("<title>Admin Home Page</title>");
out.println("<style>");
out.println(".button-container {");
out.println(" display: flex;");
out.println(" gap: 10px;");
out.println("}");
out.println(".logout-button {");
out.println(" margin-left: auto;");
out.println("}");
out.println("table {");
out.println(" border-collapse: collapse;");
out.println(" width: 100%;");
out.println("}");
out.println("th, td {");
out.println(" padding: 8px;");
out.println(" text-align: left;");
out.println("}");
out.println("th {");
out.println(" background-color: #f2f2f2;");
out.println("}");
out.println("td:not(:last-child) {");
out.println(" padding-right: 20px;");
out.println("}");
out.println("</style>");
out.println("</head>");
out.println("<body>");
out.println("<h1>Admin Home Page</h1>");
// Get the total number of railway crossings
int totalRailwayCrossings = 0;
PreparedStatement countStatement =
conn.prepareStatement("SELECT COUNT(*) FROM railway_crossings");
ResultSet countResultSet = countStatement.executeQuery();
if (countResultSet.next()) {
totalRailwayCrossings = countResultSet.getInt(1);
}
out.println("<p>Railway Crossings: [" + totalRailwayCrossings +
"]</p>");
out.println("<div class=\"button-container\">");
out.println(" <form action=\"home.jsp\" method=\"get\">");
out.println(" <button type=\"submit\">Home</button>");
out.println(" </form>");
out.println(" <form action=\"add_railway.html\" method=\"get\">");
out.println(" <button type=\"submit\">Add RailwayCrossing</button>");
out.println(" </form>");
out.println(" <form action=\"search_crossing.jsp\"method=\"get\">");
out.println(" <button type=\"submit\">SearchCrossing</button>");
out.println(" </form>");
out.println(" <form action=\"government_login.jsp\"method=\"get\" class=\"logout-button\">");
out.println(" <button type=\"submit\">Logout</button>");
out.println(" </form>");
out.println("</div>");
out.println("<table>");
out.println("<tr><th>ID</th><th>Name</th><th>Address</th><th>Landmark</th><th>Schedules</th><th>Person</th><th>Status</th><th>Action</th</tr>");
// Check if there are any railway crossings
if (!resultSet.next()) {
out.println("<tr><td colspan=\"7\">No railway crossingsfound</td></tr>");
} else {
do {
int id = resultSet.getInt("id");
String name = resultSet.getString("name");
String address = resultSet.getString("address");
String landmark = resultSet.getString("landmark");
String schedules = resultSet.getString("schedules");
String person = resultSet.getString("person");
String status = resultSet.getString("status");
out.println("<tr>");
out.println("<td>" + id + "</td>");
out.println("<td>" + name + "</td>");
out.println("<td>" + address + "</td>");
out.println("<td>" + landmark + "</td>");
out.println("<td>" + schedules + "</td>");
out.println("<td>" + person + "</td>");
out.println("<td>" + status + "</td>");
out.println("<td><a href='update_railway.jsp?id=" + id +
"'>Update</a> | <a href='DeleteRailwayCrossingServlet?id=" + id +
"'>Delete</a></td>");
out.println("</tr>");
} while (resultSet.next());
}
out.println("</table>");
out.println("</body>");
out.println("</html>");
// Close the database connections
countStatement.close();
statement.close();
conn.close();
} catch (ClassNotFoundException | SQLException e) {
e.printStackTrace();
out.println("Database error: " + e.getMessage());
}
}
}
 