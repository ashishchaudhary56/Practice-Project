package Problem5;

public class ThrowFinallyAndThrows {
	public static void main(String[] args) {
		 try {
		 divide(10, 0);
		 } catch (EkConception e) {
		 System.out.println("Exception happen " + e.getMessage());
		 } finally {
		 System.out.println("Finally block executed");
		 }
		 }
		 public static void divide(int abc, int def) throws
		 EkConception {
		 try {
		 if (def == 0) {
		 throw new EkConception("Cannot divide by zero");
		 }
		 int result = abc / def;
		 System.out.println("Result: " + result);
		 } catch (ArithmeticException e) {
		 throw new EkConception("ArithmeticException occurred",
		 e);
		 }
		 }
		 }
		 class EkConception extends Exception {
		 public EkConception(String message) {
		 super(message);
		 }
		 public EkConception(String ashish, Throwable cause) {
		 super(ashish, cause);
		 }


}
