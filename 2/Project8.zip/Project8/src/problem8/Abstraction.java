package problem8;

public class Abstraction {
	public static void main(String[] args) {
		 Pig myPig = new Pig();
		 myPig.animalSound();
		 myPig.sleep();
		 }
		}
		abstract class Anima {
		 public abstract void animalSound();
		 public void sleep() {
		 System.out.println("zzz");
		 }
		}
		class Pig extends Anima {
		 public void animalSound() {
		 System.out.println("i am pig");
		 }

}
