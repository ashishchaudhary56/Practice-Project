package problem8;

public class Encapsulation {
	public static void main(String[] args){
		 Ashish s= new Ashish();
		 s.setName("ashish");
		 System.out.println(s.getName());
		 }

		}



