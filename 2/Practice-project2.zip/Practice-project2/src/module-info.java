/**
 * 
 */
/**
 * @author Manish Kumar
 *
 */
module Practice {
}