package Problem6;

public class ExceptionHandling {
	public static void main(String[] args) {
		 try {
		 int result = divide(10, 0);
		 System.out.println("Result: " + result);
		 } catch (ArithmeticException e) {
		 System.out.println("Exception caught: " + e.getMessage());
		 } finally {
		 System.out.println("Finally block executed");
		 }
		 }
		 public static int divide(int dividend, int divisor) {
		 try {
		 int result = dividend / divisor;
		 return result;
		 } catch (ArithmeticException e) {
		 throw new ArithmeticException("Cannot divide by zero");
		 }
		 }


}
