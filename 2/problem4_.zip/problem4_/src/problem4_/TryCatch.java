package problem4_;


	public class TryCatch {
		 public static void main(String[] args) {
		 try {
		 int ash = methodDivide(10, 0);
		 System.out.println("result " + ash);
		 } catch (ArithmeticException e) {
		 System.out.println("Exception is caught: " +
		 e.getMessage());
		 }
		 }
		 public static int methodDivide(int xShe, int yMe) {
		 return xShe / yMe;


}}
