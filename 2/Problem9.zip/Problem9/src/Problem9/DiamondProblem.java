package Problem9;

public class DiamondProblem implements Ashish, Chaudhary {
	
		 public void display()
		 {
		 Ashish.super.display();
		 Chaudhary.super.display();
		 }
		 public static void main(String args[])
		 {
		 DiamondProblem obj = new DiamondProblem();
		 obj.display();
		 }
		 }
		 interface Ashish
		 {
		 public default void display()
		 {
		 System.out.println("the display() method of Ashish invoked");
		 }
		 }
		 interface Chaudhary
		 {
		 public default void display()
		 {
		 System.out.println("the display() method of Chaudhary invoked");
		 }

}
