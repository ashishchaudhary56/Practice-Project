package Ashish;

public class Synchronization {
	public static void main(String[] args) {
		 AshishRes res = new AshishRes();
		 Thread t1 = new Thread(new MyRunnable(res));
		 Thread t2 = new Thread(new MyRunnable(res));
		 t1.start();
		 t2.start();
		 }
		 }
		 class AshishRes {
		 private int count;
		 public synchronized void increment() {
		 count++;
		 System.out.println("Count incremented to= " + count);
		 }
		 }
		 class MyRunnable implements Runnable {
		 private AshishRes resource;
		 public MyRunnable(AshishRes resource) {
		 this.resource = resource;
		 }
		 public void run() {
		 for (int i = 0; i < 5; i++) {
		 resource.increment();
		 try {
		 Thread.sleep(100);
		 } catch (InterruptedException e) {
		 e.printStackTrace();
		 }
		 }
		 }

}
