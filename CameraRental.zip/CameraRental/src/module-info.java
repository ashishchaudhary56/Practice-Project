/**
 * 
 */
/**
 * @author Manish Kumar
 *
 */
module CameraRental {
}