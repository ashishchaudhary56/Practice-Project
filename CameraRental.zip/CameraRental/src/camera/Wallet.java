package camera;

public class Wallet {
private int balance;

public Wallet(int balance) {
this.balance = balance;
}
public int getBalance() {
return balance;
}
public void setBalance(int balance) {
this.balance = balance;
}
public boolean canPurchase(Camera c){
return balance>=c.getRent();
}
public void viewBalance(){
System.out.println(this.balance);
}
public void add(int rs){
balance +=rs;
System.out.println("sucessfully added");
}
}