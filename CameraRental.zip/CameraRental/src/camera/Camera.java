package camera;
import java.util.ArrayList;

import java.util.*;
public class Camera {
private String brandName;
static List<Camera> List = new ArrayList<>();
private String model;
private int rent;
private int id;

public int getId() {
return id;
}

public void setId(int id) {
this.id = id;
}

public Camera(String brandName, String model, int rentPerHour,int id) {
this.brandName = brandName;
this.id=id;
this.model = model;
this.rent = rentPerHour;
}

public String getBrandName() {
return brandName;
}

public void setBrandName(String brandName) {
this.brandName = brandName;
}

public String getModel() {
return model;
}

public void setModel(String model) {
this.model = model;
}

public int getRent() {
return rent;
}

public void setRent(int rent) {
this.rent = rent;
}
}