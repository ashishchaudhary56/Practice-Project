package camera;
//import java.sql.SQLOutput;
import java.util.Scanner;

public class Main {
private static Scanner sc = new Scanner(System.in);
public static void main(String[] args) {
User ashish = new User();
System.out.println("Welcome to the camera rental app");
System.out.println("please login to continue");

System.out.print("user id ->");
String id = sc.next();
System.out.print("enter password->");
String pass = sc.next();
if(User.isValid(id,pass)){
	
view1(ashish);
}
else {
	System.out.println("user id or pass are invalid");
}
}
public static void view1(User ashish){
System.out.println("1. My Camera\n2. Rent a Camera \n3. VIEW ALL CAMERAS \n4. MY WALLET \n5. Exit");
int n = sc.nextInt();
switch(n){
case 1:viewCamera(ashish);
break;
case 2:rent(ashish);
view1(ashish);
break;
case 3:printCamera(ashish);
view1(ashish);
break;
case 4:myWallet(ashish);
break;
case 5:
System.out.println("thank you");
}

}
static void viewCamera(User ashish){
System.out.println("1. ADD\n2. REMOVE\n3. VIEW MY CAMERAS\n4. GO TO PREVIOUS MENU");
int n = sc.nextInt();
switch(n){
case 1:
System.out.println("give Camera details");
String name = sc.next();
String model=sc.next();
int rent = sc.nextInt();
int id = sc.nextInt();
ashish.addCamera(new Camera(name,model,rent,id));
view1(ashish);
break;
case 2:
System.out.println("give camera id you want to remove");
ashish.removeCamera(sc.nextInt());
view1(ashish);
break;
case 3:
printRented(ashish);
view1(ashish);
break;
case 4:
view1(ashish);
}
}
static void rent(User ashish){
System.out.println("enter the id which camera do you want to rent");
int id = sc.nextInt();
for(var i :Camera.List){
if(i.getId()==id) {
ashish.rentCamera(i);

break;
}}}
static void printCamera(User ashish){
	
for(var i:Camera.List){
	if(i==ashish.cameraRented)
		System.out.println(i.getId()+" "+i.getBrandName()+" " +i.getModel()+" "+i.getRent()+  " Rented ");
	else
System.out.println(i.getId()+" "+i.getBrandName()+" " +i.getModel()+" "+i.getRent()+  " available ") ;
}
}
static void myWallet(User ashish){
System.out.println("1. ADD BALANCE\n2. VIEW BALANCE\n3. PREVIOUS MENU\n");
int n = sc.nextInt();
switch(n){
case 1:
System.out.println("enter amount");
int rs=sc.nextInt();
ashish.wallet.add(rs);
myWallet(ashish);
break;
case 2: ashish.wallet.viewBalance();
myWallet(ashish);
break;
case 3:
view1(ashish);
}
}
static void printRented(User ashish) {
	System.out.println(ashish.cameraRented.getBrandName()+ " " + ashish.cameraRented.getModel());
}

}
