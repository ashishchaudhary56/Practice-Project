package camera;
import java.util.*;

public class User {
static private final String id="admin";
Camera cameraRented;
Wallet wallet;
static private final String pass="admin123";
static boolean isValid(String id,String pass){
return User.id.equals(id)&&User.pass.equals(pass);
}
public User(){
this.wallet = new Wallet(0);
}
List<Camera> MyCamera = new ArrayList<>();
void addCamera(Camera camera){
Camera.List.add(camera);
System.out.println("camera added sucessfully");
}
void rentCamera(Camera camera){
if(this.wallet.canPurchase(camera)){
cameraRented = camera;
wallet.setBalance(wallet.getBalance()-camera.getRent());
System.out.println("Successfuly Rented");
}
else{
System.out.println("insufficient balance");
}
}
void removeCamera(int id){
for(var i:Camera.List){
if(i.getId()==id){
Camera.List.remove(i);
break;
}
}
}

}
